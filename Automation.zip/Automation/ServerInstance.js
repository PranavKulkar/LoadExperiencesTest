const express = require('express')();
const mongoose = require('mongoose');
const ip = require("ip");
const tunnel = require('tunnel-ssh');
var cmd=require('node-cmd');

var db;
var allotted = false;
const Myip =  ip.address();
const Listeningport = '47998';
const Protocol = 'udp';


 var config = {
    username:'db',
    host: '192.168.174.247',
    // use localPort for changing the local machine port
    dstPort:27017, // should be 27017 only
    password:'12345678'
  };
  tunnel(config, function (error, server) {
    if (error) {
      console.log('SSH connection error: ' + error);
    }
    console.log('Here');
    mongoose.connect('mongodb://127.0.0.1:27017/AjnaVidyaAutomation');
    db = mongoose.connection;
    db.on('error', console.error.bind(console, 'DB connection error:'));
    db.once('open', function () {
      // we're connected!
    console.log('DB connection successful');

    freeme();
    }); 

  });

CheckMyStatus();


function freeme()
{
  var myobj = { Status: "Free", PortOnProxyServer:"" };
  
  db.collection("ServerIPDetails").findOneAndUpdate({IPAddress : Myip},  {$set: myobj} , {
  new: true,
  upsert: true // Make this update into an upsert
  });


}



async function CheckMyStatus()
{
  while(1)
  {
    await sleep(10000);
   


   let cmd_response = "";

   cmd.run('C:/portQryV2/portQry.exe -n '+ Myip + ' -p '+ Protocol +' -e '+ Listeningport, function(err, data, stderr){

       cmd_response = data.slice(data.lastIndexOf(':')+2).trim();
       
       console.log(Myip + " with " + Listeningport + " port / " + Protocol + " protocol " + cmd_response);


       if(cmd_response == "NOT LISTENING")
       {
         
           if(allotted)
           {
            allotted = false;
            setTimeout(CheckMyStatusFinal, 10000);
            console.log('Instance Freeing up initiated');
           }
           else
           {
            console.log('Instance not Allotted');
           }

       }

       else if(cmd_response == "LISTENING or FILTERED"){

        allotted = true;
        console.log('Instance is Allotted');

       } 
   });



    
    
  
    }
  
}
function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}



function CheckMyStatusFinal()
{

  let cmd_response = "";

  cmd.run('C:/portQryV2/portQry.exe -n '+ Myip + ' -p '+ Protocol +' -e '+ Listeningport, function(err, data, stderr){

      cmd_response = data.slice(data.lastIndexOf(':')+2).trim();
      
      


      if(cmd_response == "NOT LISTENING")
      {
        freeme();
        console.log('Instance Freed up');
        

      }

      else if(cmd_response == "LISTENING or FILTERED"){

        

      } 
  });


}


function Checkport() {

    let cmd_response = "";

    cmd.run('C:/portQryV2/portQry.exe -n '+ Myip + ' -p '+ Protocol +' -e '+ Listeningport, function(err, data, stderr){

        cmd_response = data.slice(data.lastIndexOf(':')+2).trim();
        
        console.log(Myip + " with " + Listeningport + " port / " + Protocol + " protocol " + cmd_response);


        if(cmd_response == "NOT LISTENING")
        {
          
            return false;

        }

        else if(cmd_response == "LISTENING or FILTERED"){

            return true;

        } 
    });

    
}




express.listen(6000,ip.address, err => {
    err ?
      console.log("Error in server setup") :
      console.log('Server listening on port' + 6000)
  });

